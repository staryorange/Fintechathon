#Please install the packages first
# Libraries
library(shinythemes)
library(shiny)
library(ggplot2)
library(plotly)
library(dplyr)
library(rworldmap)
library(manipulate)
library(Cairo)
library(wordcloud2)
library(png)


# Read csv
table1 = read.csv("Demo数据.csv")
table1$年份 = as.factor(table1$年份)
#View(table1)
table2 = read.csv("2017年福建.csv")
#View(table2)

Demo_Art = table1[which(table1$科类=="文科"),]
Demo_Sci = table1[which(table1$科类=="理科"),]
#View(Demo_Art)

#文科
Art_graph = ggplot(Demo_Art,aes(x = 年份,y= 最高分,group = 专业名称),
                   device = cairo_pdf, family = "Song")+geom_point()
Art_graph = Art_graph + geom_line(aes(color= 专业名称))+ ggtitle("过去三年录取分数") +
theme_grey(base_family = "SimSun" )

Art_graph = Art_graph + theme(
  plot.title = element_text(color = "chocolate3", size = 15, face = "bold"))


#理科
Sci_graph = ggplot(Demo_Sci,aes(x = 年份,y= 最高分,group = 专业名称),
                   device = cairo_pdf, family = "Song")+geom_point()
Sci_graph = Sci_graph + geom_line(aes(color= 专业名称))+ ggtitle("过去三年录取分数") +
  theme_grey(base_family = "SimSun" )

Sci_graph = Sci_graph + theme(
  plot.title = element_text(color = "chocolate3", size = 15, face = "bold"))


#录取人数柱状图



#录取最低位次柱状图




###### Page 2的模型#########################################

cloud = read.csv("wordsdemo.csv")
worldcloud = wordcloud2(cloud,size = 0.4, color = "random-light", backgroundColor = "white") #颜色和背景
#wordcloud2(cloud, size = 1,shape = 'star') #形状
#wordcloud2(cloud, size = 2, minRotation = -pi/6, maxRotation = -pi/6,rotateRatio = 1) #旋转
#wordcloud2(cloud, size = 2, fontFamily = "微软雅黑",
#color = "random-light", backgroundColor = "grey") #支持中文

schooltable = read.csv("schooldemo.csv")
subjecttable = read.csv("subjectdemo.csv")
top5_school = plot_ly(schooltable, labels = ~school, values = ~percentage, type = 'pie',width = 500,sizes = 0.2) %>%
  layout(title = '推荐院校Top 6',
         xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
         yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
top5_subject = plot_ly(subjecttable, labels = ~subject, values = ~percentage, type = 'pie',width = 500,sizes = 0.2) %>%
  layout(title = '推荐专业Top 6',
         xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
         yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

###### Page 2的模型#########################################






#///////////////////////////////////////////////////////////////////////////
# Visualization 

ui = shinyUI(
  fluidPage(
    
    navbarPage("智慧教育——高考志愿填报推荐平台",

               #Page1
               tabPanel('招生简章概览',
                        
                        
                        sidebarLayout(
                          
                          sidebarPanel(
                            
                            style = "background: coral" ,
                            selectInput("placechoice","选择生源所在地",
                              choices = c ('北京市','天津市','上海市','重庆市',
                            '河北省','山西省','辽宁省','吉林省','黑龙江省',
                            '江苏省','浙江省','安徽省','福建省','江西省','山东省'
                            ,'河南省','湖北省','湖南省','广东省','海南省','四川省',
                            '贵州省','云南省','陕西省','甘肃省','青海省','台湾省'
                            ,'内蒙古自治区','广西壮族自治区','西藏自治区','宁夏回族自治区',
                            '新疆维吾尔自治区','香港特别行政区','澳门特别行政区')),
                            

                            
                            radioButtons("subject"," 选择文理科",
                                         c('文科','理科')),
                            
                            
                            selectInput("aimschool","选择意向学校",
                                        choices = c ( '清华大学','北京大学','浙江大学','中国人民大学',
                                                     '复旦大学','上海交通大学','武汉大学','南京大学',
                                                     '中山大学', '吉林大学','华中科技大学', '天津大学',
                                                     '四川大学','中南大学','中国科学技术大学','哈尔滨工业大学',
                                                     '南开大学','中国社会科学院大学','山东大学','厦门大学',
                                                     '同济大学','北京航空航天大学','大连理工大学','东北大学',
                                                     '华南理工大学','西北工业大学')),
                            
                            # Only show this panel if the plot type is a histogram
                            conditionalPanel(
                              condition = "input.subject== '文科'",
                              selectInput("direction","选择意向专业",
                              choices = c('文科试验班(元培学院)','中国语言文学类','国际政治','经济学类',
                                               '工商管理类','法学','公共管理类','英语'))),
                            
                            conditionalPanel(
                              condition = "input.subject == '理科'",
                              selectInput("direction","选择意向专业",
                                          choices = c('电子信息类','化学类','生物科学',
                                                      '理科试验班(元培学院)','经济学类','工商管理类','法学',
                                                      '物理学类'))),
                            
                            radioButtons("conditon","录取情况",
                                         c('录取人数','录取最低位次'))
                            
                      
                            
                          ),
                          
                          mainPanel(
                            plotlyOutput("enrollcondition",
                                         height = "400px",
                                         width = "700px"),
                            plotOutput("avgscore",
                                       height = "400px",
                                       width = "700px")

                           ) 
                          
                          
                          
                          
                          )

                            ),
               
               #page2
               tabPanel('性格测试',
                        
                        sidebarLayout(
                          
                          sidebarPanel(
                            
                            style = "background: coral" ,

                            # Copy the line below to make a text input box
                            textInput("grade","请输入姓名" , label = h4("DISC 性格测试题")),
                            
                            selectInput('one',"第一题",
                                        choices = c ('富于冒险','适应性强','生动','善于分析'
                                                    )),
                            
                            selectInput('two',"第二题",
                                        choices = c ('坚持不懈','喜好娱乐','善于说服','平和'
                                        )),
                            
                            selectInput('three',"第三题",
                                        choices = c ('顺服','自我牺牲','善于社交','意志坚定'
                                        )),
                            
                            selectInput('four',"第四题",
                                        choices = c ('使人认同','体贴','竞争性','自控性'
                                        )),
                            
                            selectInput('five',"第五题",
                                        choices = c ('使人振作','尊重他人','善于应变','含蓄'
                                        )),
                            
                            actionButton("Prediction", "开始测试")
                            
                            
                          ),
                          
                          mainPanel(
                            
                            imageOutput("pictures", width = "100%", height = "400px", click = NULL,
                                        dblclick = NULL, hover = NULL, hoverDelay = NULL,
                                        hoverDelayType = NULL, brush = NULL, clickId = NULL, hoverId = NULL,
                                        inline = FALSE)
                            
                          ) 
                          
                          
                        )
                        
                        
                        
               ),
               
  
             #page3
             tabPanel('智能推荐系统',
                         
                sidebarLayout(
                           
                sidebarPanel(
                  
                  style = "background: coral" ,
                  
                  # Copy the line below to make a text input box
                  textInput("grade", label = h3("请输入高考成绩")),
                  
                  selectInput("birthplace","请选择生源所在地",
                              choices = c ('北京市','天津市','上海市','重庆市',
                                           '河北省','山西省','辽宁省','吉林省','黑龙江省',
                                           '江苏省','浙江省','安徽省','福建省','江西省','山东省'
                                           ,'河南省','湖北省','湖南省','广东省','海南省','四川省',
                                           '贵州省','云南省','陕西省','甘肃省','青海省','台湾省'
                                           ,'内蒙古自治区','广西壮族自治区','西藏自治区','宁夏回族自治区',
                                           '新疆维吾尔自治区','香港特别行政区','澳门特别行政区')),
                  
                  radioButtons("character","是否加入性格测试结果",
                               c('是','否')),
                  
                  radioButtons("connection","是否联入联邦数据库查询推荐结果",
                               c('是','否')),
                  
                  
                  actionButton("goButton", "开始预测")

                  
                ),
                
                mainPanel(
                  wordcloud2Output("Cloudwords",
                                   height = "400px",
                                   width = "750px"),
                  plotlyOutput("Topschool",
                               height = "400px",
                               width = "750px")
                  ) 
                
                
                )
                         
                         
                         
                         )
             

             
  
             
    )
  

  
))


server = shinyServer(
  function(input,output,session){
    
    
    
    output$enrollcondition <- renderPlotly({
      
      art_sci <- input$subject

      if(art_sci == "文科"){
        
        subtable = table1[which(table1$科类=="文科"),]
      }
      
      else if(art_sci == "理科") {
        subtable = table1[which(table1$科类=="文科"),]
      }
      
      
      aimcondition = input$conditon
      
      if(aimcondition == "录取人数"){
        
        demobar = subtable[which(subtable$专业名称== input$direction),]
        # Bar Chart of Estimated Polulation 

        pop = ggplot(demobar ,aes(x = 年份 ,y= 录取人数))
        pop =  pop + xlab("年份") + ylab("录取人数")
        pop = pop + geom_bar(stat = "identity",fill="steelblue")
        pop= pop + ggtitle("过去三年录取人数")
        
        pop = pop + theme(
          plot.title = element_text(color = "chocolate3", size = 15, face = "bold")
        ) + theme_grey(base_family = "SimSun" )
        pop
        

        
      }
      
      else if(aimcondition == "录取最低位次") {
        
        demobar = subtable[which(subtable$专业名称== input$direction),]
        pop1 = ggplot(demobar ,aes(x = 年份 ,y= 最低位次))
        pop1 = pop1 + xlab("年份") + ylab("最低位次")
        pop1 = pop1 + geom_bar(stat = "identity",fill="orange")
        pop1= pop1 + ggtitle("过去三年录取最低位次")
        
        pop1 = pop1 + theme(
          plot.title = element_text(color = "chocolate3", size = 15, face = "bold")
        ) + theme_grey(base_family = "SimSun" )
        pop1

      }
 
    })
    

    
    #######   
    output$avgscore <- renderPlot({
      
      art_sci <- input$subject
      
      if(art_sci == "文科"){
        
        subtable = table1[which(table1$科类=="文科"),]
      }
      
      else if(art_sci == "理科") {
        subtable = table1[which(table1$科类=="文科"),]
      }

      subdirect = subtable[which(subtable$专业名称== input$direction),]
      
      direction_graph = ggplot(subdirect,aes(x = 年份,y=平均分,group = 专业名称),
                               device = cairo_pdf, family = "Song")+geom_point()
      direction_graph = direction_graph + xlab("年份") + ylab("平均分")
      direction_graph = direction_graph + geom_line(aes(color= 专业名称))+ labs(title = "过去三年录取平均分", 
                                subtitle = input$direction,colour = "专业名称"
                                ) +theme_grey(base_family = "SimSun" )
      
      direction_graph = direction_graph + theme(
        plot.title = element_text(color = "black", size = 18, face = "bold"),
        plot.subtitle = element_text(color = "darkblue",size = 14, face = "bold"),
        axis.title.x=element_text(size=16),axis.title.y=element_text(size=16)
      )
      

      direction_graph
      
      
    })    
    

    
     ######   
    
    
     observeEvent(input$goButton, {

       output$Cloudwords <- renderWordcloud2({ worldcloud })
       
       output$Topschool <- renderPlotly({
         
         subplot = plot_ly() %>%
           add_pie(schooltable, labels = ~schooltable$school, values = ~schooltable$schoolscore, type = 'pie',width = 500,sizes = 0.3,
                   name = "推荐学校", domain = list(row = 0, column = 0)) %>%
           add_pie(subjecttable, labels = ~subjecttable$subject, values = ~subjecttable$subjectscore, type = 'pie',width = 500,sizes = 0.3,
                   name = "推荐专业", domain = list(row = 0, column = 1)) %>%
           layout(title = "推荐的学校和专业", showlegend = T,
                  title = list(x = 1, y = 0.5 ), 
                  grid=list(rows=1, columns=2),
                  xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                  yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE)) 

         subplot
         
       })
       
     })
    
    ######
    
    
    observeEvent(input$Prediction, {
      
      output$pictures<- renderImage({
        imagefile <- 'tmpfile.png'  ## 设置文件名
        png(imagefile)
        par(mar=c(3, 3, 0.5, 0.5), mgp=c(2, 0.5, 0))
        plot(rnorm(20))
        dev.off()
        list(src=imagefile)  ## 这是expr的返回值
      })
      
      
    })

    ######
    
    
})


#Create app
shinyApp(ui, server)




